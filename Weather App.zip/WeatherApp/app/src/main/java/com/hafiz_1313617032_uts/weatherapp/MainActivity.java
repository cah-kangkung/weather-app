package com.hafiz_1313617032_uts.weatherapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.hafiz_1313617032_uts.weatherapp.Adapter.ForecastAdapter;
import com.hafiz_1313617032_uts.weatherapp.Model.ForecastDayModel;
import com.hafiz_1313617032_uts.weatherapp.Model.WeatherModel;
import com.hafiz_1313617032_uts.weatherapp.Retrofit.ApiClient;
import com.squareup.picasso.Picasso;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    TextView tv_location, tv_condition, tv_temp, tv_lastUpdated, tv_windKph, tv_pressureMb, tv_precipMM, tv_humidity, tv_cloud, tv_gustKph, tv_forecast_date, tv_forecast_avgtemp, tv_forecast_condition;
    // TextView tv_forecast_date0, tv_forecast_date01, tv_forecast_date02;
    // ImageView tv_forecast_icon;
    private RecyclerView recyclerView;
    private ForecastAdapter forecastAdapter;
    private RecyclerView.LayoutManager layoutManager;
    public static MainActivity mainActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv_location = findViewById(R.id.location);
        tv_condition = findViewById(R.id.condition);
        tv_temp = findViewById(R.id.temp);
        tv_lastUpdated = findViewById(R.id.last_updated);
        tv_windKph = findViewById(R.id.wind_kph);
        tv_pressureMb = findViewById(R.id.pressure_mb);
        tv_precipMM = findViewById(R.id.precip_mm);
        tv_humidity = findViewById(R.id.humidity);
        tv_cloud = findViewById(R.id.cloud);
        tv_gustKph = findViewById(R.id.gust_kph);
        // tv_icon = (ImageView)findViewById(R.id.icon);

        /*
        tv_forecast_date0 = findViewById(R.id.date0);
        tv_forecast_date01 = findViewById(R.id.date01);
        tv_forecast_date02 = findViewById(R.id.date02);
        tv_forecast_avgtemp = findViewById(R.id.forecast_avg_temp);
        tv_forecast_condition = findViewById(R.id.forecast_condition);
        */

        recyclerView = findViewById(R.id.forecast_list);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        mainActivity = this;

        getDataFromApi();
    }

    private void getDataFromApi () {
        ApiClient.endpoint().getData()
                .enqueue(new Callback<WeatherModel>() {
                    @Override
                    public void onResponse(Call<WeatherModel> call, Response<WeatherModel> response) {
                        tv_location.setText("Location: " + response.body().getLocation().getName());
                        tv_condition.setText("Condition: " + response.body().getCurrent().getCondition().getText());
                        tv_temp.setText("Temperature: " + response.body().getCurrent().getTemp_c());
                        tv_lastUpdated.setText("Last Updated: " + response.body().getCurrent().getLast_updated());
                        tv_windKph.setText("Wind Speed: " + response.body().getCurrent().getWind_kph());
                        tv_pressureMb.setText("Pressure: " + response.body().getCurrent().getPressure_mb());
                        tv_precipMM.setText("Precip: " + response.body().getCurrent().getPrecip_mm());
                        tv_humidity.setText("Humidity: " + response.body().getCurrent().getHumidity() + "%");
                        tv_cloud.setText("Cloud: " + response.body().getCurrent().getCloud() + "%");
                        tv_gustKph.setText("Wind Gust: " + response.body().getCurrent().getGust_kph());

                        List<ForecastDayModel> listForecastDay = response.body().getForecast().getForecastDayList();
                        forecastAdapter = new ForecastAdapter(listForecastDay);
                        recyclerView.setAdapter(forecastAdapter);

                        /* tv_forecast_date0.setText(response.body().getForecast().getForecastDayList().get(0).getDate());
                        tv_forecast_date01.setText(response.body().getForecast().getForecastDayList().get(1).getDate());
                        tv_forecast_date02.setText(response.body().getForecast().getForecastDayList().get(2).getDate());
                        */

                        // Picasso.get().load("https:" + response.body().getCurrent().getCondition().getIcon()).into(tv_icon);
                    }

                    @Override
                    public void onFailure(Call<WeatherModel> call, Throwable t) {

                    }
                });
    }
}