package com.hafiz_1313617032_uts.weatherapp.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.hafiz_1313617032_uts.weatherapp.Model.ForecastDayModel;
import com.hafiz_1313617032_uts.weatherapp.R;
import com.squareup.picasso.Picasso;

import java.util.List;

public class ForecastAdapter extends RecyclerView.Adapter<ForecastAdapter.ListViewHolder> {

    List<ForecastDayModel> listForecastDay;

    public ForecastAdapter(List<ForecastDayModel> mlistForecastDay) {
        listForecastDay = mlistForecastDay;
    }

    @NonNull
    @Override
    public ListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.single_forecast, parent, false);
        ListViewHolder listViewHolder = new ListViewHolder(view);
        return listViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ListViewHolder holder, int position) {
        holder.tv_date.setText(listForecastDay.get(position).getDate());
        holder.tv_avgTemp.setText(Double.toString(listForecastDay.get(position).getDay().getAvgtemp_c()));
        holder.tv_condition.setText(listForecastDay.get(position).getDay().getCondition().getText());

        Picasso.get().load("https:" + listForecastDay.get(position).getDay().getCondition().getIcon()).into(holder.tv_icon);
    }

    @Override
    public int getItemCount() {
        return listForecastDay.size();
    }

    public class ListViewHolder extends RecyclerView.ViewHolder {

        public TextView tv_date, tv_avgTemp, tv_condition;
        public ImageView tv_icon;

        public ListViewHolder(@NonNull View itemView) {
            super(itemView);

            tv_date = itemView.findViewById(R.id.forecast_date);
            tv_avgTemp = itemView.findViewById(R.id.forecast_avg_temp);
            tv_condition = itemView.findViewById(R.id.forecast_condition);
            tv_icon = (ImageView)itemView.findViewById(R.id.forecast_icon);
        }
    }
}
