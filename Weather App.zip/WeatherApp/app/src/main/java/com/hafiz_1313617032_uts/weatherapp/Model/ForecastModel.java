package com.hafiz_1313617032_uts.weatherapp.Model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ForecastModel {
    @SerializedName("forecastday")
    private List<ForecastDayModel> forecastDayList;

    public List<ForecastDayModel> getForecastDayList() {
        return forecastDayList;
    }

    public void setForecastDayList(List<ForecastDayModel> forecastDayList) {
        this.forecastDayList = forecastDayList;
    }
}
