package com.hafiz_1313617032_uts.weatherapp.Model;

public class ConditionModel {

    private String text;

    private String icon;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }
}
