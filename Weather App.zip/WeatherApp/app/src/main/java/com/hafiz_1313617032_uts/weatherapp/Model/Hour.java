package com.hafiz_1313617032_uts.weatherapp.Model;

import com.google.gson.annotations.SerializedName;

public class Hour {
    @SerializedName("time")
    private String time;
    @SerializedName("temp_c")
    private double temp_c;
    @SerializedName("condition")
    private ConditionModel condition;

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public double getTemp_c() {
        return temp_c;
    }

    public void setTemp_c(double temp_c) {
        this.temp_c = temp_c;
    }

    public ConditionModel getCondition() {
        return condition;
    }

    public void setCondition(ConditionModel condition) {
        this.condition = condition;
    }
}
